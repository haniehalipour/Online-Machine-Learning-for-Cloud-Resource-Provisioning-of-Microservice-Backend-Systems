exports.handler = (event, context, callback) => {
    // TUTORIAL
	// http://parsitech.co/wiki/item/25-aws-lambda-ssh.html
    var message = event.Records[0].Sns.Message.replace(/'/g, '"');
    var json_message = JSON.parse(message);
    //callback(null, json_message.state);
    
    var SSH = require('simple-ssh');
	var fs = require('fs');
	
	console.log('request is :' + json_message.state);
	
	if (json_message.state == 'add_node')
	{
		/*****************
		## ADD NEW NODE ##
		*****************/
		callback(null, 'ADD NEW NODE');
		
		/*###############################
		## Connect to Ansible Instance ##
		###############################*/
		callback(null, 'Connect to Ansible Instance');
		var ansible_nstance = new SSH({
			host: json_message.ansible_dns,
			user: 'ubuntu',
			key: fs.readFileSync("ec2_keypair.pem")
		});
		
		ansible_nstance.exec('sudo ansible-playbook -i /etc/ansible/hosts /root/create-ec2-1.yaml -u ubuntu', {
			out: function(stdout){
				console.log(stdout);//Show Output
			},err: function(stderr) {
				console.log(stderr);//show errors
			},exit: function(code, stdout, stderr) {
    console.log('operation exited with code: ' + code);
    console.log('STDOUT from EC2:\n' + stdout);
    console.log('STDERR from EC2:\n' + stderr);
    console.log('Next line we will terminate ssh!');
    ansible_nstance.end();
 		}
		}).start();
	}
	else if (json_message.state == 'remove_node')
	{
		/****************
		## REMOVE NODE ##
		****************/
		callback(null, 'REMOVE NODE');
		var node_should_delete = new SSH({
			host: json_message.target_node_dns,
			user: 'ubuntu',
			key: fs.readFileSync("ec2_keypair.pem")
		});
		
		/*################################################
		## Connect to Node instance which should delete ##
		################################################*/
		callback(null, 'Connect to Node instance which should delete');
		node_should_delete.exec('sudo nodetool decommission', {
			out: function(stdout) {
				console.log(stdout);
			},
			err: function(stderr) {
				console.log(stderr);//show errors
			}
		}).exec('echo "exiting shell"',{
			out: function(stdout){
				node_should_delete.end();
			},
			err: function(stderr) {
				node_should_delete.end();
			}
		}).start();
		
		/*###############################
		## Connect to Ansible Instance ##
		###############################*/
		callback(null, 'Connect to Ansible Instance');
		var ansible_nstance = new SSH({
			host: json_message.ansible_dns,
			user: 'ubuntu',
			key: fs.readFileSync("ec2_keypair.pem")
		});
		
		ansible_nstance.exec('sudo ansible-playbook -i /etc/ansible/hosts -u ubuntu /root/cassandra-cleanup.yaml', {
			err: function(stderr) {
				console.log(stderr);//show errors
			}
		}).exec('echo "exiting shell"',{
			out: function(stdout){
				ansible_nstance.end();
			},
			err: function(stderr) {
				ansible_nstance.end();
			}
		}).start();
	}
	else if (json_message.state == 'rejoin_node')
	{
		/****************
		## REJOIN NODE ##
		****************/
		callback(null, 'REJOIN NODE');
		var node_should_rejoin = new SSH({
			host: json_message.target_node_dns,
			user: 'ubuntu',
			key: fs.readFileSync("ec2_keypair.pem")
		});
		
		/*################################################
		## Connect to Node instance which should rejoin ##
		################################################*/
		callback(null, 'Connect to Node instance which should rejoin');
		node_should_rejoin.exec('sudo rm -rf /var/lib/cassandra/data/system/*', {
			out: function(stdout) {
				console.log(stdout);
			},
			err: function(stderr) {
				console.log(stderr);//show errors
			}
		}).exec('sudo service cassandra stop', {
			out: function(stdout) {
				console.log(stdout);
			},
			err: function(stderr) {
				console.log(stderr);//show errors
			}
		}).exec('sudo cassandra -R -Dcassandra.override_decommission=true', {
			out: function(stdout) {
				console.log(stdout);
			},
			err: function(stderr) {
				console.log(stderr);//show errors
			}
		}).exec('echo "exiting shell"',{
			out: function(stdout){
				node_should_rejoin.end();
			},
			err: function(stderr) {
				node_should_rejoin.end();
			}
		}).start();
		
		/*###############################
		## Connect to Ansible Instance ##
		###############################*/
		callback(null, 'Connect to Ansible Instance');
		var ansible_nstance = new SSH({
			host: json_message.ansible_dns,
			user: 'ubuntu',
			key: fs.readFileSync("ec2_keypair.pem")
		});
		
		ansible_nstance.exec('sudo ansible-playbook -i /etc/ansible/hosts -u ubuntu /root/cassandra-cleaup.yaml', {
			err: function(stderr) {
				console.log(stderr);//show errors
			}
		}).exec('echo "exiting shell"',{
			out: function(stdout){
				ansible_nstance.end();
			},
			err: function(stderr) {
				ansible_nstance.end();
			}
		}).start();
	}
};